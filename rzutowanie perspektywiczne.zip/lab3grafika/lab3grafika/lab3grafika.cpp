#include "pch.h"
#include <windows.h>
#include <math.h>
#include <iostream>
#include <gl/gl.h>
#include <glut.h>


typedef float point3[3];

static GLfloat viewer[] = { 0.0, 0.0, 10.0 };
static GLfloat viewerCamera[] = { 0.0,0.0,10.0 };
static GLfloat theta = 0.0;
static GLfloat thetaDeg = 0.0;
static GLfloat scale = 10.0;
static GLfloat pix2angle;     
static int model = 1;
static GLint status = 0;      

static int x_pos_old = 0;       

static int delta_x = 0;

static GLfloat fi = 0.0;
static GLfloat fiDeg = 0.0;

static int y_pos_old = 0;

static int y_pos_old_right = 0;

static int delta_y = 0;

static int delta_y_right = 0;

void Axes(void)
{

	point3  x_min = { -5.0, 0.0, 0.0 };
	point3  x_max = { 5.0, 0.0, 0.0 };
	
	point3  y_min = { 0.0, -5.0, 0.0 };
	point3  y_max = { 0.0,  5.0, 0.0 };
	
	point3  z_min = { 0.0, 0.0, -5.0 };
	point3  z_max = { 0.0, 0.0,  5.0 };
	
	glColor3f(1.0f, 0.0f, 0.0f);  
	glBegin(GL_LINES); 
	glVertex3fv(x_min);
	glVertex3fv(x_max);
	glEnd();

	glColor3f(0.0f, 1.0f, 0.0f);  
	glBegin(GL_LINES);  

	glVertex3fv(y_min);
	glVertex3fv(y_max);
	glEnd();

	glColor3f(0.0f, 0.0f, 1.0f);  
	glBegin(GL_LINES); 

	glVertex3fv(z_min);
	glVertex3fv(z_max);
	glEnd();

}

void Mouse(int btn, int state, int x, int y)
{
	if (btn == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		x_pos_old = x;
		y_pos_old = y;
		status = 1;          
	}
	else if(btn == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{
		y_pos_old_right=y;
		status = 2;
	}
	else

		status = 0;          
}

void Motion(GLsizei x, GLsizei y)
{

	delta_x = x - x_pos_old;     
	delta_y = y - y_pos_old;
	x_pos_old = x; 
	y_pos_old = y;
	delta_y_right = y - y_pos_old_right;
	y_pos_old_right = y;
	glutPostRedisplay();     
}


void RenderScene(void)
{

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	
	
	if (status == 1)
	{
		theta += (delta_x * pix2angle*3.1415926)/180;
		fi += (delta_y * pix2angle*3.1415926)/180;
		fiDeg += delta_y * pix2angle;
		thetaDeg += delta_x * pix2angle;
		while (fiDeg > 360)
			fiDeg -= 360;
		while (fiDeg < 0)
			fiDeg += 360;
		thetaDeg += delta_x * pix2angle;
		while (thetaDeg > 360)
			thetaDeg -= 360;
		while (thetaDeg < 0)
			thetaDeg += 360;
	}
	if (status == 2)
	{
		scale += delta_y_right * pix2angle;
	}
	if (scale > 20)
		scale = 20;
	if (scale < 2)
		scale = 2;
	if (model == 1)
	{
		viewerCamera[0] = scale * cos(theta)*cos(fi);
		viewerCamera[1] = scale * sin(fi);
		viewerCamera[2] = scale * sin(theta)*cos(fi);
		std::cout << fiDeg << std::endl;
		if (fiDeg >= 90 && fiDeg <= 270)
		{
			gluLookAt(viewerCamera[0], viewerCamera[1], viewerCamera[2], 0.0, 0.0, 0.0, 0.0, -1.0, 0.0);
		}
		else
		{
			gluLookAt(viewerCamera[0], viewerCamera[1], viewerCamera[2], 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
		}
		Axes();
	}
	
	if (model == 2)
	{
		
		gluLookAt(viewer[0], viewer[1], viewer[2], 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
		Axes();
		glTranslatef(0.0, 0.0, scale/10);
		glRotatef(thetaDeg, 0.0, 1.0, 0.0);
		glRotatef(fiDeg, 1.0, 0.0, 0.0);
	}
	
	glColor3f(1.0f, 1.0f, 1.0f);
	glutWireTeapot(3.0);
	glFlush();
	glutSwapBuffers();
}

void keys(unsigned char key, int x, int y)
{
	if (key == 'p') model = 1;
	if (key == 'w') model = 2;

	RenderScene();
}

void MyInit(void)
{

	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

}

void ChangeSize(GLsizei horizontal, GLsizei vertical)
{
	pix2angle = 360.0 / (float)horizontal;
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(70, 1.0, 1.0, 300.0);
	if (horizontal <= vertical)
		glViewport(0, (vertical - horizontal) / 2, horizontal, horizontal);

	else
		glViewport((horizontal - vertical) / 2, 0, vertical, vertical);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}


void main(void)
{

	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

	glutInitWindowSize(300, 300);

	glutCreateWindow("Rzutowanie perspektywiczne");

	glutMouseFunc(Mouse);
	glutMotionFunc(Motion);
	glutKeyboardFunc(keys);
	glutDisplayFunc(RenderScene);
	glutReshapeFunc(ChangeSize);

	MyInit();
	glEnable(GL_DEPTH_TEST);

	glutMainLoop();
}